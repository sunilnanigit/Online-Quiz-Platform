public class User {
    private int id;
    private String username;
    private String password; // You should hash this for security

    // Getters and Setters
}