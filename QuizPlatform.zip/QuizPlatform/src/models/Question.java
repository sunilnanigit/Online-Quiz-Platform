public class Question {
    private int id;
    private String questionText;
    private String questionType; // "multiple_choice" or "true_false"

    // Getters and Setters
}