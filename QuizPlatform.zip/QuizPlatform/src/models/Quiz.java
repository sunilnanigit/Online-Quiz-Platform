public class Quiz {
    private int id;
    private String title;
    private String category;

    // Getters and Setters
}