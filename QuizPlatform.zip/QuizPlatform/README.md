# Quiz Platform

## Overview
This project is a quiz platform built using Java and JavaFX.

## Features
- User Registration and Login
- Multiple Quiz Categories
- Various Question Formats (Multiple Choice, True/False)
- Scoring System and Timer
- Instant Feedback on Answers
- Admin Panel for Managing Quizzes

## Setup
1. Install JDK and an IDE (IntelliJ IDEA or Eclipse).
2. Add JavaFX library to your project.
3. Run `Main.java` to start the application.

## Future Updates
- Implement additional question formats.
- Enhance security features.